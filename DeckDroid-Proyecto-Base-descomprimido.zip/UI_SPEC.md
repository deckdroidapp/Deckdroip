
# DeckDroid UI - Dinámica y Fácil

Pantalla Principal:
- Hero con animación de teléfono transformándose en Steam Deck
- Un solo botón gigante: "CONVERTIR EN STEAM DECK"
- Barra de progreso con mensajes humanos: "Instalando magia..."
- Cards de juegos gratis: Mindustry, SuperTuxKart, Xonotic + botón "Ver más en Tienda Gratis"
- Sección mandos: icono Bluetooth que vibra cuando detecta mando, muestra "Xbox Controller conectado"

Juegos Gratis incluidos (open source, legal 100%):
- Mindustry (estrategia)
- SuperTuxKart (carreras tipo Mario Kart)
- Xonotic (shooter arena)
- Shattered Pixel Dungeon
- Más via Flathub integrado en escritorio Linux LXQt

No incluimos juegos piratas ni APKs de Steam. El usuario usa su propia cuenta de Steam para sus juegos.
