
package com.deckdroid.launcher

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.deckdroid.launcher.databinding.ActivityMainBinding

// DeckDroid MainActivity - 1-Click Auto Installer
// Basado en DroidDeck GPL-3.0 - com.droiddeck.launcher original
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val installer = AutoInstallerService()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.title.text = "DeckDroid"
        binding.subtitle.text = "Tu teléfono es una Steam Deck. Un tap."

        // Flujo 1-Click
        binding.btnInstall.setOnClickListener {
            installer.startFullSetup(
                context = this,
                onProgress = { pct, msg -> runOnUiThread {
                    binding.progressBar.progress = pct
                    binding.statusText.text = msg
                }},
                onComplete = { runOnUiThread {
                    binding.statusText.text = "¡Listo! Iniciando Steam Big Picture..."
                    installer.launchSteam(this)
                }},
                onError = { err -> runOnUiThread {
                    binding.statusText.text = "Error: $err - Revisa Opciones de Desarrollador"
                }}
            )
        }

        // Detección mando Bluetooth
        BluetoothHelper.listen(this) { controllerName ->
            binding.controllerStatus.text = "Mando conectado: $controllerName - Mapeado como Steam Deck"
        }
    }
}
