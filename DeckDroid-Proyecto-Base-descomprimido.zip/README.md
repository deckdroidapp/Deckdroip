# DeckDroid - Tu Teléfono es una Steam Deck
Gratis y Open-Source. Fork de DroidDeck GPL-3.0

## Que es?
DeckDroid automatiza todo el proceso de DroidDeck para que el usuario solo instale 1 APK y juegue.

## Como compilar SIN Android Studio (desde el celular)
1. Crea un repo nuevo en github.com y sube esta carpeta.
2. Ve a pestaña Actions -> Activa workflows.
3. El archivo .github/workflows/build.yml compilará el APK solo. En 5 min tendrás el APK listo en Releases.
4. Descárgalo e instálalo en tu Android.

## Legal / Open Source
- Licencia GPL-3.0 como DroidDeck original.
- NO incluye cliente de Steam. Se descarga en primer inicio desde servidores oficiales de Valve (obligatorio por TOS).
- Juegos gratis incluidos son 100% libres (Flathub / Open Source) y demos free-to-play de Steam.
- Código original DroidDeck: https://github.com/Droid-Deck/DroidDeck
